// +build !windows

// Copyright 2017 Tamás Gulácsi
//
//
// SPDX-License-Identifier: UPL-1.0 OR Apache-2.0

package goracle

// #cgo LDFLAGS: -ldl -lpthread
import "C"
