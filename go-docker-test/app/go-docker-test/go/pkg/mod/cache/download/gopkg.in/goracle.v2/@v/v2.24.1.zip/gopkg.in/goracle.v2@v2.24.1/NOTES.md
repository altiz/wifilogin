# Database Change Notification vs. Query Result Change Notification #
See http://comments.gmane.org/gmane.comp.python.db.cx-oracle/2944
