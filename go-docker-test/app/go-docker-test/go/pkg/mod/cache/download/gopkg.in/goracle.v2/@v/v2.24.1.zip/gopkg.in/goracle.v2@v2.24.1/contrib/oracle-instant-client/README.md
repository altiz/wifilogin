# Oracle-instant-client

Migrate oracle client from repo(https://github.com/sergeymakinen/docker-oracle-instant-client)