Sorry, Pull Requests for ODPI-C cannot be accepted. Please report bugs and ask questions using [GitHub issues](https://github.com/oracle/odpi/issues)
